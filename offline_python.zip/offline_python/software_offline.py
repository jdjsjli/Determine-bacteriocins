from tkinter import filedialog
from tkinter.messagebox import showwarning
from tkinter import Menu
from tkinter import messagebox
import numpy as np
import tkinter as tk
from tkinter import Toplevel, Button, Label
import os
from tkinter import ttk
import time
import pandas as pd
import webview
import openpyxl
import threading
import tensorflow as tf
import tensorflow_hub as hub
import tensorflow_text
import h5py
from sklearn.model_selection import train_test_split

# BERT预训练模型
BERT_MODEL = "./experts_bert_wiki_books_2"
# 序列输入BERT模型之前的预处理
PREPROCESS_MODEL = "./bert_en_uncased_preprocess_3"
result = {}
def read_fasta_file(filepath):
    sequences = []  # 使用列表来存储序列
    with open(filepath, 'r') as f:
        lines = f.readlines()
    seq = ''
    for line in lines:
        line = line.strip()  # 去掉行尾的换行符
        if line.startswith('>'):
            if seq:  # 如果当前序列非空，则保存前一个序列
                sequences.append(seq)
                seq = ''  # 重置序列
        else:
            seq += line  # 添加序列部分
    # 保存最后一个序列
    if seq:
        sequences.append(seq)
    sequence_count = len(sequences)
    return sequences, sequence_count  # 返回包含所有序列的列表和数量


def predicted_function_file(filepath, BERT_MODEL, PREPROCESS_MODEL):
    pos_pr_sentences, pos_len = read_fasta_file(filepath)
    X = np.zeros((pos_len, 200, 768))  # 初始化测试集特征矩阵
    progressbar['value'] = 0
    progressbar['maximum'] = pos_len
    # 加载pr序列的预处理模型
    preprocessor = hub.load(PREPROCESS_MODEL)
    # 定义输入层
    text_inputs = [tf.keras.layers.Input(shape=(), dtype=tf.string)]
    # 得到序列分词列表
    tokenize = hub.KerasLayer(preprocessor.tokenize)
    tokenized_inputs = [tokenize(segment) for segment in text_inputs]
    seq_length = 202  # 设定输入的序列最大长度，200+CLS+SEP
    # 序列分词列表转化为BERT模型的输入向量
    bert_pack_inputs = hub.KerasLayer(preprocessor.bert_pack_inputs, arguments=dict(seq_length=seq_length))
    encoder_inputs = bert_pack_inputs(tokenized_inputs)
    # 以下代码块定义BERT模型
    encoder = hub.KerasLayer(BERT_MODEL, trainable=False)  # 用BERT模型编码
    outputs = encoder(encoder_inputs)
    # [batch_size, 768]，模型的最终输出
    pooled_output = outputs["pooled_output"]
    # [batch_size, seq_length,768]，序列编码输出
    sequence_output = outputs["sequence_output"]
    # 定义输出特征的BERT模型，注意这里需要用sequence_output
    bert_model = tf.keras.Model(text_inputs, sequence_output)
    for i in range(pos_len):
        pr_sentence = tf.constant(pos_pr_sentences[i])
        pr_sentence = np.expand_dims(pr_sentence, axis=0)
        pr_feature = bert_model(pr_sentence)  # 特征向量为[1, 202,768]
        pr_feature = pr_feature[:, 1:201, :]  # 去掉CLS和SEP，新维度为[1,200,768]
        # 写入训练集矩阵
        X[i] = pr_feature  # pr序列的特征
        progressbar['value'] = i + 1
        window.update_idletasks()  # 更新界面
    file_train = h5py.File('./pr_my2.hdf5', 'w')
    dataset = file_train.create_dataset("X", data=X)
    file_train.close()
    model = tf.keras.models.load_model('my_model.h5')
    f = h5py.File('./pr_my2.hdf5', 'r')
    X = f['X'][...]
    f.close()
    X = X.reshape((len(X), 200, 256, 3))
    predictions = model.predict(X)
    predicted_class = np.where(predictions > 0.5, 1, 0)
    return predicted_class, pos_len, pos_pr_sentences

def predicted_function_text(sentences_text, BERT_MODEL, PREPROCESS_MODEL):
    pos_len = 1
    progressbar['value'] = 0
    progressbar['maximum'] = pos_len
    pos_pr_sentences = [sentences_text]
    X = np.zeros((pos_len, 200, 768))  # 初始化测试集特征矩阵
    # 加载pr序列的预处理模型
    preprocessor = hub.load(PREPROCESS_MODEL)
    # 定义输入层
    text_inputs = [tf.keras.layers.Input(shape=(), dtype=tf.string)]
    # 得到序列分词列表
    tokenize = hub.KerasLayer(preprocessor.tokenize)
    tokenized_inputs = [tokenize(segment) for segment in text_inputs]
    seq_length = 202  # 设定输入的序列最大长度，200+CLS+SEP
    # 序列分词列表转化为BERT模型的输入向量
    bert_pack_inputs = hub.KerasLayer(preprocessor.bert_pack_inputs, arguments=dict(seq_length=seq_length))
    encoder_inputs = bert_pack_inputs(tokenized_inputs)
    # 以下代码块定义BERT模型
    encoder = hub.KerasLayer(BERT_MODEL, trainable=False)  # 用BERT模型编码
    outputs = encoder(encoder_inputs)
    # [batch_size, 768]，模型的最终输出
    pooled_output = outputs["pooled_output"]
    # [batch_size, seq_length,768]，序列编码输出
    sequence_output = outputs["sequence_output"]
    # 定义输出特征的BERT模型，注意这里需要用sequence_output
    bert_model = tf.keras.Model(text_inputs, sequence_output)
    # 调用BERT模型，完成序列编码，存储到HDF5格式的文件作为数据集
    # 对样本编码
    for i in range(pos_len):
        pr_sentence = tf.constant(pos_pr_sentences[i])
        pr_sentence = np.expand_dims(pr_sentence, axis=0)
        pr_feature = bert_model(pr_sentence)  # 特征向量为[1, 202,768]
        pr_feature = pr_feature[:, 1:201, :]  # 去掉CLS和SEP，新维度为[1,200,768]
        # 写入训练集矩阵
        X[i] = pr_feature  # pr序列的特征
        progressbar['value'] = i + 1
        window.update_idletasks()  # 更新界面
    file_train = h5py.File('./pr_my2.hdf5', 'w')
    dataset = file_train.create_dataset("X", data=X)
    file_train.close()
    model = tf.keras.models.load_model('my_model.h5')
    f = h5py.File('./pr_my2.hdf5', 'r')
    X = f['X'][...]
    f.close()
    X = X.reshape((len(X), 200, 256, 3))
    predictions = model.predict(X)
    predicted_class = np.where(predictions > 0.5, 1, 0)
    return predicted_class, pos_len

def convert_binary_to_strings_2d(binary_2d_list):
    return [['不是' if item == 0 else '是' for item in binary_list] for binary_list in binary_2d_list]
def upload_file():
    try:
        file_path = filedialog.askopenfilename()  # 弹出文件选择对话框
        if file_path:
            extension = os.path.splitext(file_path)[1].lstrip('.')
            if extension.lower() != 'fasta':  # 检查文件扩展名，忽略大小写
                showwarning("警告", "文件格式错误,请检查后重新上传")
                return  # 结束函数执行
            if messagebox.askyesno("确认", "文件格式正确，是否开始判断？"):
                # 用户确认上传，执行上传操作
                with open(file_path, 'rb') as file:
                    label1.configure(bg="#d9e2f2", fg="#b6b5b8")
                    label2.configure(bg="#d9e2f2", fg="#000000")
                    label3.configure(bg="#d9e2f2", fg="#b6b5b8")
                    frame1.place_forget()
                    text_box.place_forget()
                    start_text_button.place_forget()
                    label4.place(x=110, y=270, width=200, height=20)
                    progressbar.place(x=100, y=300, width=600, height=15)
                    messagebox.showinfo("提示",
                                        "数据集特征提取的时间与数据集规模以及计算力相关，可能需要数分钟，请勿点击软件的其他摁钮，请耐心等待...")
                    predicted, num_seq, pr_seq_list = predicted_function_file(file_path, BERT_MODEL, PREPROCESS_MODEL)
                    messagebox.showinfo("提示", "文件判断成功")
                    predicted_list = predicted.tolist()
                    predicted_list = convert_binary_to_strings_2d(predicted_list)
                    global result
                    result = dict(zip(pr_seq_list, predicted_list))
                    progressbar.step(1)  # 设置进度条为完成
                    label4.place_forget()
                    label5.place(x=110, y=270, width=200, height=20)
                    after_coculate_button.place(x=600, y=475, width=75, height=30)
    except Exception as e:
        messagebox.showerror("错误", f"文件上传过程中发生错误: {e}")

def text_start():
    seq = {'seq': text_box.get('1.0', 'end').rstrip('\n')}  # 获取文本框中的数据
    label1.configure(bg="#d9e2f2", fg="#b6b5b8")
    label2.configure(bg="#d9e2f2", fg="#000000")
    label3.configure(bg="#d9e2f2", fg="#b6b5b8")
    frame1.place_forget()
    text_box.place_forget()
    start_text_button.place_forget()
    label4.place(x=110, y=270, width=200, height=20)
    progressbar.place(x=100, y=300, width=600, height=15)
    messagebox.showinfo("提示", "数据集特征提取的时间与数据集规模以及计算力相关，可能需要数分钟，请耐心等待...")
    predicted, pr_seq_list = predicted_function_text(seq, BERT_MODEL, PREPROCESS_MODEL)
    predicted_list = predicted.tolist()
    predicted_list = convert_binary_to_strings_2d(predicted_list)
    messagebox.showinfo("提示", "文件判断成功")
    global result
    result = dict(zip(pr_seq_list, predicted_list))
    progressbar.step(1)  # 设置进度条为完成
    label4.place_forget()
    label5.place(x=110, y=270, width=200, height=20)
    after_coculate_button.place(x=600, y=475, width=75, height=30)

def about():
    messagebox.showinfo("提示",
                        "数据集特征提取的时间与数据集规模以及计算力相关，可能需要数分钟，请耐心等待...")
def version():
    messagebox.showinfo("提示",
                        "版本号1.0.0")
def after_coculate():
    label5.place_forget()
    progressbar.place_forget()
    after_coculate_button.place_forget()
    label1.configure(bg="#d9e2f2", fg="#b6b5b8")
    label2.configure(bg="#d9e2f2", fg="#b6b5b8")
    label3.configure(bg="#d9e2f2", fg="#000000")
    text_result.place(x=65, y=145, width=670, height=250)
    output_button.place(x=345, y=425, width=110, height=40)

def output():
    global result
    df = pd.DataFrame(list(result.items()), columns=['蛋白质序列', '是否为细菌素'])
    # 打开一个保存文件对话框，让用户选择文件保存位置和文件名
    file_path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                             filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                                             title="Save Excel file")
    if file_path:
        df.to_excel(file_path, index=False)
def biapr():
    # 页面显现(1)
    pr_button.configure(bg="#FFFFFF", fg="#4472c4", relief="flat",
                                     activebackground="#4472c4", activeforeground="#FFFFFF")
    frame1.place(x=75, y=135, width=165, height=40)
    frame1.configure(bg="#4472c4")
    label1.place(x=55, y=55, width=230, height=50)
    label1.configure(bg="#d9e2f2", fg="#000000")
    label2.place(x=285, y=55, width=230, height=50)
    label2.configure(bg="#d9e2f2", fg="#b6b5b8")
    label3.place(x=515, y=55, width=230, height=50)
    label3.configure(bg="#d9e2f2", fg="#b6b5b8")
    text_box.place(x=65, y=205, width=670, height=250)
    start_text_button.place(x=600, y=475, width=75, height=30)
    # 隐藏其他部分
    # (1)
    label4.place_forget()
    label5.place_forget()
    progressbar.place_forget()
    after_coculate_button.place_forget()
    output_button.place_forget()
    text_result.place_forget()
    # (2)
    DNAdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                        activebackground="#4472c4", activeforeground="#FFFFFF")
    labelA.place_forget()
    button1_1.place_forget()
    button1_2.place_forget()
    button1_3.place_forget()
    button1_4.place_forget()
    button1_5.place_forget()
    button1_6.place_forget()
    button1_7.place_forget()
    # (3)
    prdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                             activebackground="#4472c4", activeforeground="#FFFFFF")
    labelB.place_forget()
    button2_1.place_forget()
    button2_2.place_forget()
    button2_3.place_forget()
    button2_4.place_forget()
    button2_5.place_forget()
    button2_6.place_forget()
    button2_7.place_forget()
    button2_8.place_forget()
    button2_9.place_forget()
    button2_10.place_forget()
    button2_11.place_forget()
    # (4)
    bioinformations_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                             activebackground="#4472c4", activeforeground="#FFFFFF")
    labelC.place_forget()
    button3_1.place_forget()
    button3_2.place_forget()
    button3_3.place_forget()
    button3_4.place_forget()

def dnadata():
    #页面显现(2)
    DNAdata_button.configure(bg="#FFFFFF", fg="#4472c4", relief="flat",
                             activebackground="#4472c4", activeforeground="#FFFFFF")
    labelA.place(x=75, y=50, width=650, height=60)
    button1_1.place(x=90, y=135, width=230, height=50)
    button1_1.configure(fg="#4472c4", relief="flat")
    button1_2.place(x=90, y=185, width=230, height=50)
    button1_2.configure(fg="#4472c4", relief="flat")
    button1_3.place(x=90, y=235, width=230, height=50)
    button1_3.configure(fg="#4472c4", relief="flat")
    button1_4.place(x=90, y=285, width=230, height=50)
    button1_4.configure(fg="#4472c4", relief="flat")
    button1_5.place(x=90, y=335, width=230, height=50)
    button1_5.configure(fg="#4472c4", relief="flat")
    button1_6.place(x=90, y=385, width=230, height=50)
    button1_6.configure(fg="#4472c4", relief="flat")
    button1_7.place(x=90, y=435, width=230, height=50)
    button1_7.configure(fg="#4472c4", relief="flat")

    #隐藏其他部分
    #(1)
    pr_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                        activebackground="#4472c4", activeforeground="#FFFFFF")
    frame1.place_forget()
    label1.place_forget()
    label2.place_forget()
    label3.place_forget()
    label4.place_forget()
    label5.place_forget()
    progressbar.place_forget()
    text_box.place_forget()
    start_text_button.place_forget()
    after_coculate_button.place_forget()
    output_button.place_forget()
    text_result.place_forget()
    #(3)
    prdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                        activebackground="#4472c4", activeforeground="#FFFFFF")
    labelB.place_forget()
    button2_1.place_forget()
    button2_2.place_forget()
    button2_3.place_forget()
    button2_4.place_forget()
    button2_5.place_forget()
    button2_6.place_forget()
    button2_7.place_forget()
    button2_8.place_forget()
    button2_9.place_forget()
    button2_10.place_forget()
    button2_11.place_forget()
    #(4)
    bioinformations_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                        activebackground="#4472c4", activeforeground="#FFFFFF")
    labelC.place_forget()
    button3_1.place_forget()
    button3_2.place_forget()
    button3_3.place_forget()
    button3_4.place_forget()

def prdata():
    # 页面显现(3)
    prdata_button.configure(bg="#FFFFFF", fg="#4472c4", relief="flat",
                             activebackground="#4472c4", activeforeground="#FFFFFF")
    labelB.place(x=75, y=50, width=650, height=60)
    button2_1.place(x=90, y=135, width=230, height=50)
    button2_1.configure(fg="#4472c4", relief="flat")
    button2_2.place(x=90, y=185, width=230, height=50)
    button2_2.configure(fg="#4472c4", relief="flat")
    button2_3.place(x=90, y=235, width=230, height=50)
    button2_3.configure(fg="#4472c4", relief="flat")
    button2_4.place(x=90, y=285, width=230, height=50)
    button2_4.configure(fg="#4472c4", relief="flat")
    button2_5.place(x=90, y=335, width=230, height=50)
    button2_5.configure(fg="#4472c4", relief="flat")
    button2_6.place(x=90, y=385, width=230, height=50)
    button2_6.configure(fg="#4472c4", relief="flat")
    button2_7.place(x=90, y=435, width=230, height=50)
    button2_7.configure(fg="#4472c4", relief="flat")
    button2_8.place(x=480, y=135, width=230, height=50)
    button2_8.configure(fg="#4472c4", relief="flat")
    button2_9.place(x=480, y=185, width=230, height=50)
    button2_9.configure(fg="#4472c4", relief="flat")
    button2_10.place(x=480, y=235, width=230, height=50)
    button2_10.configure(fg="#4472c4", relief="flat")
    button2_11.place(x=480, y=285, width=230, height=50)
    button2_11.configure(fg="#4472c4", relief="flat")
    # 隐藏其他部分
    # (1)
    pr_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                                     activebackground="#4472c4", activeforeground="#FFFFFF")
    frame1.place_forget()
    label1.place_forget()
    label2.place_forget()
    label3.place_forget()
    label4.place_forget()
    label5.place_forget()
    progressbar.place_forget()
    text_box.place_forget()
    start_text_button.place_forget()
    after_coculate_button.place_forget()
    output_button.place_forget()
    text_result.place_forget()
    # (2)
    DNAdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                                     activebackground="#4472c4", activeforeground="#FFFFFF")
    labelA.place_forget()
    button1_1.place_forget()
    button1_2.place_forget()
    button1_3.place_forget()
    button1_4.place_forget()
    button1_5.place_forget()
    button1_6.place_forget()
    button1_7.place_forget()
    # (4)
    bioinformations_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                                     activebackground="#4472c4", activeforeground="#FFFFFF")
    labelC.place_forget()
    button3_1.place_forget()
    button3_2.place_forget()
    button3_3.place_forget()
    button3_4.place_forget()
def bioinformations_tool():
    # 页面显现(4)
    bioinformations_button.configure(bg="#FFFFFF", fg="#4472c4", relief="flat",
                            activebackground="#4472c4", activeforeground="#FFFFFF")
    labelC.place(x=75, y=50, width=650, height=60)
    button3_1.place(x=90, y=135, width=230, height=50)
    button3_1.configure(fg="#4472c4", relief="flat")
    button3_2.place(x=90, y=185, width=230, height=50)
    button3_2.configure(fg="#4472c4", relief="flat")
    button3_3.place(x=90, y=235, width=230, height=50)
    button3_3.configure(fg="#4472c4", relief="flat")
    button3_4.place(x=90, y=285, width=230, height=50)
    button3_4.configure(fg="#4472c4", relief="flat")
    # 隐藏其他部分
    # (1)
    pr_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                        activebackground="#4472c4", activeforeground="#FFFFFF")
    frame1.place_forget()
    label1.place_forget()
    label2.place_forget()
    label3.place_forget()
    label4.place_forget()
    label5.place_forget()
    progressbar.place_forget()
    text_box.place_forget()
    start_text_button.place_forget()
    after_coculate_button.place_forget()
    output_button.place_forget()
    text_result.place_forget()
    # (2)
    DNAdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                             activebackground="#4472c4", activeforeground="#FFFFFF")
    labelA.place_forget()
    button1_1.place_forget()
    button1_2.place_forget()
    button1_3.place_forget()
    button1_4.place_forget()
    button1_5.place_forget()
    button1_6.place_forget()
    button1_7.place_forget()
    # (3)
    prdata_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                            activebackground="#4472c4", activeforeground="#FFFFFF")
    button2_1.place_forget()
    button2_2.place_forget()
    button2_3.place_forget()
    button2_4.place_forget()
    button2_5.place_forget()
    button2_6.place_forget()
    button2_7.place_forget()
    button2_8.place_forget()
    button2_9.place_forget()
    button2_10.place_forget()
    button2_11.place_forget()

# 创建一个窗口对象
window = tk.Tk()
# 设置窗口标题
window.title("细菌素判断")
# 设置窗口大小
window.geometry("800x600")
window.configure(bg="#EEEEEE")

# 设置窗口的大小
window_width = 800
window_height = 600

# 获取屏幕宽度和高度
screen_width = window.winfo_screenwidth()
screen_height = window.winfo_screenheight()

# 计算窗口在屏幕中的位置
x_coordinate = int((screen_width - window_width) / 2)
y_coordinate = int((screen_height - window_height) / 2)

# 设置窗口的位置和大小
window.geometry(f"{window_width}x{window_height}+{x_coordinate}+{y_coordinate}")


# 创建菜单栏
menu_bar = Menu(window)
window.config(menu=menu_bar)

# 创建“帮助”菜单
help_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="帮助", menu=help_menu)
help_menu.add_command(label="关于", command=about)
# 创建“版本”菜单
ver_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="版本", menu=ver_menu)
ver_menu.add_command(label="版本号", command=version)
# 创建“退出”菜单
file_menu = Menu(menu_bar, tearoff=0)
menu_bar.add_cascade(label="退出", command=window.quit)



frame1 = tk.Frame(window)
frame1.place(x=75, y=135, width=165, height=40)
frame1.configure(bg="#4472c4")

frame2 = tk.Frame(window)
frame2.place(x=0, y=525, width=800, height=75)
frame2.configure(bg="#4472c4")

label1 = tk.Label(window, text="输入需预测基因序列")
label1.place(x=55, y=55, width=230, height=50)
label1.configure(bg="#d9e2f2", fg="#000000")
label2 = tk.Label(window, text="计算预测")
label2.place(x=285, y=55, width=230, height=50)
label2.configure(bg="#d9e2f2", fg="#b6b5b8")
label3 = tk.Label(window, text="结果查看和分析")
label3.place(x=515, y=55, width=230, height=50)
label3.configure(bg="#d9e2f2", fg="#b6b5b8")

input_button = tk.Button(frame1, text="手动输入")
input_button.place(x=5, y=5, width=75, height=30)
input_button.configure(bg="#FFFFFF", fg="#4472c4", relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")

# 创建上传按钮，点击时会调用 upload_file 函数
upload_button = tk.Button(frame1, text="上传文件", command=upload_file)
upload_button.place(x=85, y=5, width=75, height=30)
upload_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")
# 创建文本框
text_box = tk.Text(window)
text_box.place(x=65, y=205, width=670, height=250)
text_box.configure(font=("宋体", 12))
def clear_default_text(event):
    if text_box.get("1.0", tk.END) == "请输入一个蛋白质序列\n":
        text_box.delete("1.0", tk.END)
text_box.insert(tk.END, "请输入一个蛋白质序列")
text_box.bind("<FocusIn>", clear_default_text)

# 创建滚动条
scroll_bar = tk.Scrollbar(text_box, command=text_box.yview)
scroll_bar.pack(side=tk.RIGHT, fill=tk.Y)
text_box.configure(yscrollcommand=scroll_bar.set)

# 创建开始判断按钮，点击时会调用 text_start 函数
start_text_button = tk.Button(window, text="开始判断", command=text_start)
start_text_button.place(x=600, y=475, width=75, height=30)
start_text_button.configure(bg="#4472c4", fg="#FFFFFF", activebackground="#FFFFFF", activeforeground="#4472c4")

# #计算预测
label4 = tk.Label(window, text="正在分析中，请耐心等待......")
label4.place(x=110, y=270, width=200, height=20)
label4.place_forget()

# #计算结束
label5 = tk.Label(window, text="分析结束，请查看结果")
label5.place(x=110, y=270, width=200, height=20)
label5.place_forget()

# 进度条的最大值
max_value = 100

# 创建进度条
progressbar = ttk.Progressbar(window, length=max_value, maximum=max_value, mode='determinate')
progressbar.place(x=100, y=300, width=600, height=15)
progressbar.place_forget()

# 创建查看结果按钮，点击时会调用 after_coculate 函数
after_coculate_button = tk.Button(window, text="查看结果", command=after_coculate)
after_coculate_button.place(x=600, y=475, width=75, height=30)
after_coculate_button.configure(bg="#4472c4", fg="#FFFFFF",
                       activebackground="#FFFFFF", activeforeground="#4472c4")
after_coculate_button.place_forget()


# 创建生成报告文件按钮，点击时会调用 output 函数
output_button = tk.Button(window, text="生成报告文件", command=output)
output_button.place(x=345, y=425, width=110, height=40)
output_button.configure(bg="#4472c4", fg="#FFFFFF", activebackground="#FFFFFF", activeforeground="#4472c4")
output_button.place_forget()

# 创建一个Text用于显示多行文本
text_result = tk.Text(window)
text_result.place(x=65, y=145, width=670, height=250)
text_result.insert(tk.END, " 具体结果请下载文件后查询")
text_result.config(state='disabled')
text_result.configure(font=("宋体", 28))
text_result.place_forget()



pr_button = tk.Button(window, text="细菌素预测", command=biapr)
pr_button.place(x=60, y=525, width=170, height=50)
pr_button.configure(bg="#FFFFFF", fg="#4472c4",relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")

labelA = tk.Label(window, text="基因组下载")
labelA.place(x=75, y=50, width=650, height=60)
labelA.configure(bg="#d9e2f2", fg="#000000", font=("宋体", 26))
labelA.place_forget()
DNAdata_button = tk.Button(window, text="基因组下载", command=dnadata)
DNAdata_button.place(x=230, y=525, width=170, height=50)
DNAdata_button.configure(bg="#4472c4", fg="#FFFFFF",relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")

def open_webview1_1():
    webview_window = webview.create_window('NCBI', 'https://www.ncbi.nlm.nih.gov/')
    webview.start()

button1_1 = tk.Button(window, text="NCBI", command=open_webview1_1)
button1_1.place()
button1_1.place_forget()

def open_webview1_2():
    webview_window = webview.create_window('EnsemblPlants', 'https://plants.ensembl.org/index.html')
    webview.start()

button1_2 = tk.Button(window, text="EnsemblPlants", command=open_webview1_2)
button1_2.place()
button1_2.place_forget()

def open_webview1_3():
    webview_window = webview.create_window('Ensembl', 'https://useast.ensembl.org')
    webview.start()

button1_3 = tk.Button(window, text="Ensembl", command=open_webview1_3)
button1_3.place()
button1_3.place_forget()

def open_webview1_4():
    webview_window = webview.create_window('Phytozome', 'https://phytozome-next.jgi.doe.gov/')
    webview.start()

button1_4 = tk.Button(window, text="Phytozome", command=open_webview1_4)
button1_4.place()
button1_4.place_forget()

def open_webview1_5():
    webview_window = webview.create_window('UCSC Genome Browse', 'https://genome.ucsc.edu/')
    webview.start()

button1_5 = tk.Button(window, text="UCSC Genome Browse", command=open_webview1_5)
button1_5.place()
button1_5.place_forget()

def open_webview1_6():
    webview_window = webview.create_window('Published Plant Genomes', 'https://www.plabipd.de/plant_genomes_pa.ep')
    webview.start()

button1_6 = tk.Button(window, text="Published Plant Genomes", command=open_webview1_6)
button1_6.place()
button1_6.place_forget()

def open_webview1_7():
    webview_window = webview.create_window('国家基因组科学数据中心', 'https://ngdc.cncb.ac.cn/?lang=zh')
    webview.start()

button1_7 = tk.Button(window, text="国家基因组科学数据中心", command=open_webview1_7)
button1_7.place()
button1_7.place_forget()




labelB = tk.Label(window, text="蛋白质工具")
labelB.place(x=75, y=50, width=650, height=60)
labelB.configure(bg="#d9e2f2", fg="#000000", font=("宋体", 26))
labelB.place_forget()
prdata_button = tk.Button(window, text="蛋白质工具", command=prdata)
prdata_button.place(x=400, y=525, width=170, height=50)
prdata_button.configure(bg="#4472c4", fg="#FFFFFF",relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")

def open_webview2_1():
    webview_window = webview.create_window('蛋白质三维结构预测：AlphaFold2', 'https://colab.research.google.com/github/sokrypton/ColabFold/blob/main/AlphaFold2.ipynb')
    webview.start()

button2_1 = tk.Button(window, text="蛋白质三维结构预测：AlphaFold2", command=open_webview2_1)
button2_1.place()
button2_1.place_forget()

def open_webview2_2():
    webview_window = webview.create_window('PDB蛋白质三维结构', 'http://www.rcsb.org/pdb')
    webview.start()

button2_2 = tk.Button(window, text="PDB蛋白质三维结构", command=open_webview2_2)
button2_2.place()
button2_2.place_forget()

def open_webview2_3():
    webview_window = webview.create_window('SWISS-PROT蛋白质序列数据库', 'http://kr.expasy.org/sprot/')
    webview.start()

button2_3 = tk.Button(window, text="SWISS-PROT蛋白质序列数据库", command=open_webview2_3)
button2_3.place()
button2_3.place_forget()

def open_webview2_4():
    webview_window = webview.create_window('PIR蛋白质序列数据库', 'http://pir.georgetown.edu/')
    webview.start()

button2_4 = tk.Button(window, text="PIR蛋白质序列数据库", command=open_webview2_4)
button2_4.place()
button2_4.place_forget()

def open_webview2_5():
    webview_window = webview.create_window('OWL非冗余蛋白质序列', 'http://www.bioinf.man.ac.uk/dbbrowser/OWL/')
    webview.start()

button2_5 = tk.Button(window, text="OWL非冗余蛋白质序列", command=open_webview2_5)
button2_5.place()
button2_5.place_forget()

def open_webview2_6():
    webview_window = webview.create_window('PROSITE蛋白质功能位点', 'http://kr.expasy.org/prosite/')
    webview.start()

button2_6 = tk.Button(window, text="PROSITE蛋白质功能位点", command=open_webview2_6)
button2_6.place()
button2_6.place_forget()

def open_webview2_7():
    webview_window = webview.create_window('DSSP蛋白质二级结构参数', 'http://www.cmbi.kun.nl/gv/dssp/')
    webview.start()

button2_7 = tk.Button(window, text="DSSP蛋白质二级结构参数", command=open_webview2_7)
button2_7.place()
button2_7.place_forget()

def open_webview2_8():
    webview_window = webview.create_window('FSSP已知空间结构的蛋白质家族', 'http://www.ebi.ac.uk/dali/fssp/fssp.html')
    webview.start()

button2_8 = tk.Button(window, text="FSSP已知空间结构的蛋白质家族", command=open_webview2_8)
button2_8.place()
button2_8.place_forget()

def open_webview2_9():
    webview_window = webview.create_window('SCOP蛋白质分类数据库', 'http://scop.mrc-lmb.cam.ac.uk/scop/')
    webview.start()

button2_9 = tk.Button(window, text="SCOP蛋白质分类数据库", command=open_webview2_9)
button2_9.place()
button2_9.place_forget()

def open_webview2_10():
    webview_window = webview.create_window('CATH蛋白质分类数据库', 'http://www.biochem.ucl.ac.uk/bsm/cath/')
    webview.start()

button2_10 = tk.Button(window, text="CATH蛋白质分类数据库", command=open_webview2_10)
button2_10.place()
button2_10.place_forget()

def open_webview2_11():
    webview_window = webview.create_window('Pfam蛋白质家族和结构域', 'http://pfam.wustl.edu/')
    webview.start()

button2_11 = tk.Button(window, text="Pfam蛋白质家族和结构域", command=open_webview2_11)
button2_11.place()
button2_11.place_forget()








labelC = tk.Label(window, text="生物信息学工具")
labelC.place(x=75, y=50, width=650, height=60)
labelC.configure(bg="#d9e2f2", fg="#000000", font=("宋体", 26))
labelC.place_forget()
bioinformations_button = tk.Button(window, text="生物信息学工具", command=bioinformations_tool)
bioinformations_button.place(x=570, y=525, width=170, height=50)
bioinformations_button.configure(bg="#4472c4", fg="#FFFFFF", relief="flat",
                       activebackground="#FFFFFF", activeforeground="#4472c4")

def open_webview3_1():
    webview_window = webview.create_window('sentieon(Call SNP)', 'https://support.sentieon.com/manual/#')
    webview.start()

button3_1 = tk.Button(window, text="sentieon(Call SNP)", command=open_webview3_1)
button3_1.place()
button3_1.place_forget()

def open_webview3_2():
    webview_window = webview.create_window('共线性工具Syri', 'https://github.com/schneebergerlab/syri')
    webview.start()

button3_2 = tk.Button(window, text="共线性工具Syri", command=open_webview3_2)
button3_2.place()
button3_2.place_forget()

def open_webview3_3():
    webview_window = webview.create_window('published plant genomes', 'https://www.plabipd.de/plant_genomes_pa.ep')
    webview.start()

button3_3 = tk.Button(window, text="published plant genomes", command=open_webview3_3)
button3_3.place()
button3_3.place_forget()

def open_webview3_4():
    webview_window = webview.create_window('MSA_pipeline', 'https://bitbucket.org/bucklerlab/msa_pipeline/src/master/')
    webview.start()

button3_4 = tk.Button(window, text="MSA_pipeline", command=open_webview3_4)
button3_4.place()
button3_4.place_forget()


# 运行事件循环
window.mainloop()